import { ScrollView, View, StyleSheet, Text, Image, Button } from 'react-native';

function Title(){
    return(
        <View>
            <Text style={styles.Text}>Adote um animal!</Text>
        </View>
    );
}

function Main(){
    return(
        <View>
            <Text style={styles.Text}>Chinchila</Text>
            <Image source={{uri: 'https://www.petz.com.br/blog/wp-content/uploads/2018/11/chinchila-como-cuidar.jpg'}}
            style={{width: 300, height: 300}} />
            <Button title="Quero esse!" color="#DE5526"/>

            <Text style={styles.Text}>Musaranho</Text>
            <Image source={{uri: 'https://nhpbs.org/wild/images/elephantshrew.jpg'}} style={{width: 300, height: 300}}/>
            <Button title="Quero esse!" color="#DE5526"/>
        </View>
    );
}

export default function App() {
  return (
    <ScrollView>
      <View style={styles.container}>
        <View style={styles.components}>
            <Title/>
            <Main/>
        </View>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  Text:{
        fontSize: 20,
        textAlign: "center",
        marginBottom: 20,
        fontWeight: "bold",
        textDecorationLine: "underline",
  },
  container: {
    flex: 1,
    backgroundColor: '#F58136',
    alignItems: 'center',
    justifyContent: 'center',
  },
  components:{
    marginTop: 50,
    marginBottom: 20, 
  }
});
