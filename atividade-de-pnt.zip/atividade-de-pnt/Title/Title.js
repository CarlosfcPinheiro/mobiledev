import react from "react";
import { View, Text, StyleSheet} from "react-native";

export default function Title(){
    return(
        <View>
            <Text style={styles.Text}>Adote um animal!</Text>
        </View>
    );
}

const styles = StyleSheet.create({
    Text:{
        fontSize: 20,
        textAlign: "center",
        marginBottom: 20,
        fontWeight: "bold",
        textDecorationLine: "underline",
    }
});

