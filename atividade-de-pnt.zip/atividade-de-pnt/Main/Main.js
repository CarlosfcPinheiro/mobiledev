import react from "react";
import {Image, Button, View, Text, StyleSheet } from "react-native";

export default function Main(){
    return(
        <View>
            <Text style={styles.Text}>Chinchila</Text>
            <Image source={{uri: 'https://www.petz.com.br/blog/wp-content/uploads/2018/11/chinchila-como-cuidar.jpg'}}
            style={{width: 300, height: 300}} />
            <Button title="Quero esse!" color="#DE5526"/>

            <Text style={styles.Text}>Musaranho</Text>
            <Image source={{uri: 'https://nhpbs.org/wild/images/elephantshrew.jpg'}} style={{width: 300, height: 300}}/>
            <Button title="Quero esse!" color="#DE5526"/>
        </View>
    );
}

const styles = StyleSheet.create({
    Text:{
        textAlign:"center",
        marginTop: 10,
    },
})